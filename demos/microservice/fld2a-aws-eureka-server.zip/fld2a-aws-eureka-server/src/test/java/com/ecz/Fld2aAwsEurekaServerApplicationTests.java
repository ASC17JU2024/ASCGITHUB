package com.ecz;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Fld2aAwsEurekaServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
