package com.ecz;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Fld2aAwsEurekaServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(Fld2aAwsEurekaServerApplication.class, args);
	}

}
